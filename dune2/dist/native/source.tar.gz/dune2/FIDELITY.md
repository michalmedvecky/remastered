# V1.07 fidelity implementation, release 0.4

Release0.4 adds a separate [HD presentation](HD-GRAPHICS.md). Native simulation, original framebuffer and recorded DOS comparisons remain authoritative; the HD artwork intentionally changes the displayed pixels. New read-only C hooks capture actual terrain and sprite decisions without forcing extra native redraws. Historical release0.2/0.3 browser captures remain separately labeled; new HD acceptance is in `fidelity/hd/`.


The default browser game now executes the complete recovered C core, replacing the first release’s approximate JavaScript terrain, combat and object state machines. The original UNIT, BUILD and TEAM EMC programs dispatch into native C callbacks operating on the engine’s own object pools, script state, map and game clocks. Native menus, campaign progression, WSA cutscenes and IFF save/load routines are retained. The browser executes the rebuilt C engine. The supplied DOS EXE was also executed in the separately authorized, bounded DOSBox-X comparisons on disposable copies described below.

The requested five areas have native implementations and selected original-runtime comparisons. It is not proof that all native behavior has been recovered without differences. Observed binary facts, reconstructed source behavior, tests of newly compiled code and unobserved original runtime behavior remain distinct below.

## Evidence and implementation

| Area | Implemented behavior and evidence | Verification |
|---|---|---|
| Terrain | Original seed byte RNG, 272-nibble grid, perturbation, interpolation, smoothing, thresholds, spice walks and neighbor icon masks; original signed SAR displacement, packed-distance and border behavior. [Report](fidelity/terrain/README.md), [patch](fidelity/terrain/patch-native.py), [instruction verification](fidelity/terrain/source-verification.json). | 51 complete generator cases: 48 distinct mission seeds plus 0, 1 and 0xffffffff. All 4,096 icon IDs/types and final RNG bytes/draw counts match an independent compiled C oracle. Terrain-only MAP projections cover all 66 scenarios; they exclude preceding unit/structure creation. 3,241 saved instructions in 16 functions were checked against relocated original bytes. Original runtime comparison adds three generator seeds, two Field cases and nine full-game allocator/save loads (36,864 baseline IDs), all exact in scope. |
| Combat | Native integer geometry, route buffers, projectile-as-unit scheduling, collision, splash, special weapons, deviation, death/reaction and AI paths run together. Original speed rounding, byte cooldown wrap, fire bounds, signed delay and refinery arithmetic/statistic behavior are patched. [Report](COMBAT-FIDELITY.md), [findings](fidelity/combat/compatibility-findings.json). | 280,126 speed, 50,108 normalized-ratio and 50,108 rounded-scale vectors compared with literal assembly-semantics models. 1,044/1,053 unit-table numeric cells match; remaining nine are invalid-action sentinel representation. 5,854 original-instruction combat fixtures now agree after the further runtime corrections below. Declared service stubs limit branch coverage. |
| Native callbacks | All 104 initialized slots, including 79 slots used by the supplied EMC scripts and their 76 distinct original addresses. [JSON ledger](fidelity/combat/callback-ledger.json), [TSV](fidelity/combat/callback-ledger.tsv). | Original pointer bytes and MZ relocations verified; every used slot has raw decompilation and assembly references. All 86 source implementations have source contracts. Table correspondence and contracts do not prove every helper branch equivalent. |
| Cutscenes | All ten intro/interlude/ending sequences retain native frame flags, continuation/XOR data, indexed palette, subtitle timing, skip behavior, voice scheduling and credits paths. Native voice records and three narration queues restored. [Report](fidelity/CUTSCENES.md), [tables](fidelity/cutscenes/native-tables.json). | All 75 animation rows, 72 subtitles and 92 sound events match original table records. The native cutscene interpreter is unchanged from pinned upstream. The patched C VOC decoder matches every PCM byte, rate and count for all 223 resources, including silence-only FILLER.VOC and nine trailing-silence blocks. |
| Music | Original file/subsong selection drives the Westwood ADL interpreter, with an exact rational 72 Hz score clock, original fade program and shared SFX channels. Nuked OPL renders the register stream in an AudioWorklet. [Provenance](native/music/PROVENANCE.md), [results](native/music/test-results.json). | All 38 music-table records and 21 original ADL bank hashes checked. All 37 nonzero mappings rendered for eight seconds: 34 audible, three absent ADL entries correctly silent. PCM is invariant under render chunk sizes at 48 kHz; timing, SFX, fade and synchronous host command ordering are tested. Selected original DOSBox-X score/SFX/fade/credits register streams were compared and SFX attenuation corrected. No physical hardware waveform comparison is claimed. |

The earlier Ghidra function inventory and unresolved classifications remain in the original analysis. Reusing recovered C code does not turn that inventory into proof of complete function discovery or equivalence.

OpenDUNE is pinned at `ebea79aeba025be2fe9004570e9255044aacc0be`. AdPlug and Nuked revisions and all modifications are retained with their licenses. `g_dune2_enhanced` is disabled. The engine source is a comparison reference and implementation dependency, not a substitute for original-binary evidence.

## Browser hardware layer

The core is compiled with Emscripten 7.0.0, SDL2 2.32.10 and Asyncify. Its cooperative wait yields to the browser; native 120/60 Hz callback intervals remain intact. A monotonic foreground clock excludes hidden-tab time, and both music and sampled audio pause in hidden tabs. Video converts the full native indexed framebuffer before presenting, because WebGL backbuffers and locked textures cannot be assumed to retain partial dirty rectangles. Display stretches 320×200 to the original 4:3 presentation and uses nearest-neighbor sampling.

Keyboard events are scoped to the canvas so help, save import and volume controls do not issue game commands. Browser help/save dialogs pause the clock and audio while open. The browser launch checkbox can skip the initial introduction once; the original Replay Introduction command remains available. Native personal files live in an automatically persisted IDBFS mount at `/save`. The original menu enumerates contiguous `_saveNNN.dat` names, so imports append into the first free slot and preserve existing saves. Original `SAVE000.DAT` and browser `_save000.dat` envelopes are accepted; unrelated or truncated IFF files are rejected. Exported saves use the recovered native IFF format, including OpenDUNE’s ODUN extension. An exported port save was loaded and re-saved by the original DOS game. Both that DOS re-save and a clean original save load in the rebuilt native engine; independently parsed unit/building core fields agree. These named files establish cross-loading for those cases, not universal interchange.

## Acceptance checks and artifacts

`npm test` covers the historical JS harness separately from the new terrain, cutscene/VOC, music, browser clock and native-save checks. `npm run test:native` compiles compatibility tests against the actual patched C source. `npm run build` verifies asset references, native output/source-package hashes and original preloaded data. Results and browser observations are retained in `fidelity/` and summarized in [PROGRESS.md](fidelity/PROGRESS.md).

Historical release0.2 browser observations are recorded in `fidelity/browser-acceptance.json`; final release0.3 intro and DOS-save import/load checks are in `fidelity/dos-browser-acceptance.json`. They cover the original intro/menu flow and the final build’s controls, campaign and native save checks as explicitly listed there; they do not imply a full campaign playthrough. [Source package record](fidelity/source-package.json) binds the downloadable complete patched source to the final WASM hashes. The source archive excludes proprietary original data and includes the selected SDL2 source archive and all component notices.

## Authorized DOSBox-X comparison results

The user authorized the bounded experiments on 18 November 2026. All runs used private in-memory guest filesystems with copied inputs, no host-folder mount, disabled IPX/NE2000 networking, per-run fixed cycle counts and hard time bounds (12,000 cycles for media captures; 30,000 in terrain allocator cases). The original ZIP and all 19 extracted files retain their SHA-256 hashes. Modified finale selectors, sound configuration, controlled function fixtures and observation hooks have explicit patch ledgers. No patch was applied to an original input.

| Experiment | Original execution and comparison | Result / correction |
|---|---|---|
| Terrain | Seeds 392, 12 and 0xffffffff; nine successful full-game save loads in fresh allocators, plus direct generator and two spice-field probes | All 36,864 captured baseline icon IDs and final RNG bytes match the C core. Direct generator and named Field operations match all 4,096 cells. Historical JS slab/wall classification was corrected; native terrain needed no new change. |
| Combat and callbacks | 460 speed, 111 Fire, 4,608 directional movement, 66 projectile, 401 deviation and 208 damage fixtures executing original instructions | All 5,854 cases match after correcting byte-facing interpretation, aircraft firing while turning, structure-edge range layout, unsupported-weapon return, signed movement rounding, Ordos deviation control and retained targets. Service stubs and excluded branches are listed in the combat report. |
| Scenes | Full original introduction and all three endings, followed by bounded credits samples; timestamped indexed VGA, palettes and OPL writes | All 54 active rows occur in order; all six byte-inspected continuation/stable frames agree. Intro full-frame identities match 327/336 samples (including logos). Remaining samples include randomized reveals, mixed VRAM updates and finish/credits transitions, explicitly retained. Long native scene runs exposed and fixed an absent-first-frame decode in continuation WSAs and an INI bounds read. Sanitized runs cover all four sequences. Full browser/DOS wall-time equivalence is not asserted. |
| Music | Original score, shared cutscene SFX, fade and credits register traces | Corrected version-3 SFX volume scaling/rounding. The original score/SFX golden streams now agree byte for byte. Fade steps agree until the original scene switches banks; credits prefixes also agree. Initialization writes, bank-switch cutoff and sample timing are reported explicitly. |
| Saves | Port export loaded/re-saved in DOS; original and DOS-resaved files loaded by the full rebuilt engine | Three loader checks preserve all 47 unit and three building common-field records. Native extensions are ignored correctly in the tested DOS load. |

The full workspace evidence, original traces, comparison programs, rejected exploratory attempts and per-run hashes are retained in the separate research archive at `analysis/dune-2/dos-comparison/`. The preserved archive’s `REPORT.md` is the entry point; [RESEARCH.md](RESEARCH.md) maps the compact evidence included in this repository. Compact golden fixtures and reproducible compatibility tests accompany the source download. Original instruction execution in controlled probes is distinct from running a complete mission: graphics, allocation and other service stubs are declared per probe. Original table pointers were not treated as proof that the next picture had already appeared.

## Remaining uncertainty

* Real allocator snapshots now cover the three named seeds, including observed out-of-map neighbor classes. Other adjacent-memory states and object-overlaid complete mission maps remain outside those assertions; the safe terrain model stays explicit.
* The archive lacks `OK.VOC`. Three music mappings point at absent ADL entries and intentionally produce silence.
* The bounded runs do not cover every campaign, weapon interaction or full credits cycle. Recovered code, original-instruction fixture results and full-game observations remain separate evidence categories.
* DOSBox-X VGA/OPL observations are the runtime reference. Physical AdLib output, browser resampling, MT-32/CM-32L synthesis and exact browser/DOS wall-clock equality are not claimed. Headless native scene timing advances on cooperative waits and excludes CPU/disk costs.
* The tested saves cross-load successfully. Other game versions and unusual save states have not all been tested.

## Collection migration

This release is integrated into `michalmedvecky/remastered` at `/dune2/`.
The compiled native core and music binaries and C/C++ engine sources retain their
validated hashes. Prefix navigation, portable tests, source packaging and build
verification were adapted. Portable tests consume the shipped preload rather
than private Mac paths. They preserve retained-table checks while keeping fresh
EXE re-extraction explicitly separate. The unified k3s image and manifest
renderer live at the collection root; no original DOS execution or cluster
rollout is part of this migration. See [RESEARCH.md](RESEARCH.md).
